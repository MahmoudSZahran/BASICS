# BasicBlocks
This Repo contains RTL codes for basic logic blocks (eg. Counter, mux … etc.), using Verilog HDL.
